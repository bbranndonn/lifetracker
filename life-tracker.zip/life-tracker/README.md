# Life Tracker — quick start

## Run

Install Node.js 20.19+ or 22.12+, then in this folder:

```sh
npm ci
npm run dev
```

Open **http://127.0.0.1:5173**. Sample data is ready to explore.

## Connect your sheet

Click **Connect your sheet** and enter:

1. **Google Sheet URL or ID** — paste your sheet link or ID.
2. **OAuth web client ID** — your Google web application client ID ending in `.apps.googleusercontent.com`.

Choose **Save connection**, then **Connect Google**. Authorize the Google account that can read your sheet.

The app automatically reads all tabs named **January through December**, ignoring capitalization and surrounding spaces. Other names (including `Jan`, `Summary`, and `January 2026`) are ignored. New month tabs are detected every refresh; dates across all imported tabs feed the existing filters.

Each month tab’s header row must contain **Date, Category, Activity, Minutes, Optional Note**. Use actual Sheets dates or `YYYY-MM-DD` text and positive numeric minutes. Categories and activities are detected automatically.

**Need the OAuth client ID?** Follow the six setup steps in [QUICKSTART.md](QUICKSTART.md), or expand the authorization instructions inside Settings. Never paste a client secret or access token.

The app refreshes every five minutes while open and authorized. Reconnect when Google access expires. Cached data and settings persist locally. Log edits made in this dashboard are local adjustments; edit the sheet to change the source.

## Build and test

```sh
npm test
npm run build
```

Deploy `dist/` to a static HTTPS host, then register that origin in Google Cloud. See [QUICKSTART.md](QUICKSTART.md) for calculation definitions, privacy details, and troubleshooting.
