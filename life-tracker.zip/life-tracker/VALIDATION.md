# Validation record

Validated on September 18, 2026.

- Production Vite build passed.
- All 16 automated test groups passed (`npm test`): strict and serial dates, leap years, DST-safe arithmetic, week boundaries, malformed rows and headers, weekly totals and comparisons, target scaling, hidden categories and activity filters, zero denominators, inactive activities, streaks, stable row identities/local adjustments, API request construction, expired credentials, network failures, and HTTP 400/401/403/404/429/500 states.
- Browser rendering checked at desktop (1440×1000) and phone portrait (390×844); no horizontal document overflow at either size.
- Category filter checked: Fitness displayed 5.4h, 2 activities, and 90% of its 6h target against the demo fixture.
- Settings persistence checked by changing Career to 15h and adding Learning with 3h, reloading, and confirming the combined target changed from 35h to 41h. Test changes were restored afterward.
- Mobile navigation and Daily Log rendering checked.
- No runtime error or warning reported in the browser log inspected during validation.

Not live-tested: Google consent and fetching a real private sheet, because no OAuth client ID or sheet was supplied during the build. API request and error behavior were tested using mocked fetch responses. Five-minute scheduling is implemented with a 300000ms interval; no real authenticated five-minute sync cycle was run.

The source reference contained the full textual specification and original spreadsheet screenshot. The generated dashboard mockup itself was not available in the retrieved attachments; the finished interface follows the supplied textual layout, palette, metrics, and minimal visual direction.

Month-tab update: production build and all tests passed. Added tests cover exact/case-insensitive month matching, exclusion of other tabs, combining monthly rows, tab-scoped row identities, warning attribution, discovery of newly added tabs, empty tabs, no matching tabs, incomplete API results, and invalid month headers. Real authorization still requires the user’s OAuth client.
