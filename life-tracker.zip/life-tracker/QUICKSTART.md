# Life Tracker

A responsive React dashboard for the time you want to make for your life. Explore the included, clearly labeled sample data immediately, then connect your private Google Sheet.

## Start locally

Requires Node.js 20.19+ or 22.12+ and npm.

```sh
npm ci
npm run dev
```

Open **http://127.0.0.1:5173**. The app includes Dashboard, Daily Log, Activities, Goals, Trends, and Settings. To create a production build, run `npm run build`; deploy the generated `dist` folder to any static HTTPS host. Register the deployed origin with Google before connecting there. Browser storage is separate for each origin/device.

## Prepare your Google Sheet

Name your log tabs **January**, **February**, … **December**, with these headers in row 1 of each tab. Column order can vary; field names are case-insensitive.

| Date | Category | Activity | Minutes | Optional Note |
|---|---|---|---:|---|
| 2026-09-18 | Career | Interview Practice – Sales | 45 | Discovery practice |
| 2026-09-18 | Fitness | Gym | 70 | Push |
| 2026-09-18 | Relationships | Cristina – Quality Time | 120 | Dinner |

Use real Google Sheets dates or ISO text (`YYYY-MM-DD`). English text like `Sep 18 2026` is also supported. Yearless text such as `Sep 18` assumes the current calendar year; use a year for reliable historical analysis. Ambiguous numeric text dates are rejected. Minutes must be positive numbers. Blank rows are ignored; invalid rows are skipped with their row numbers reported. New categories and activities appear automatically after refresh. Data is read from columns A:ZZ across every tab whose full name is an English month (ignoring case and surrounding spaces). Other tabs are ignored; `Jan` or `January 2026` do not match. Tabs are rediscovered each refresh, and all imported dates feed the dashboard filters. Source tabs are shown in Daily Log. Calendar-style grids with dates across columns must first be converted to the row-based format above; no public sharing or publishing is required.

## Authorize Google Sheets

1. In [Google Cloud Console](https://console.cloud.google.com/), create or choose a project and enable **Google Sheets API** under APIs & Services → Library.
2. Configure **Google Auth Platform** branding and audience (or OAuth consent screen in older console navigation). For a personal external app in Testing, add your own Google account as a test user. Configure the read-only scope `https://www.googleapis.com/auth/spreadsheets.readonly` in Data Access if prompted.
3. Create an OAuth client of type **Web application**. Under **Authorized JavaScript origins**, add `http://127.0.0.1:5173`. If you instead browse `http://localhost:5173`, add that exact origin too. Origins have no path or trailing slash. Add your exact HTTPS origin when hosting. The popup token flow does not need a redirect URI or a client secret.
4. In the dashboard, open **Settings**, paste the client ID ending in `.apps.googleusercontent.com`, your sheet URL. Month tabs are selected automatically. Choose **Save connection**.
5. Choose **Connect Google**, select an account with access to the sheet, and grant read-only Sheets permission. If Google identity was still loading, the app asks you to click Connect Google again. Allow the sign-in popup. If Google rejects the embedded in-app browser, open the same local dashboard URL in Chrome or Safari and connect there. Settings are browser-specific, so paste the client ID and sheet URL there as well.
6. Log new rows in Google Sheets. The dashboard pulls updates every **5 minutes** while the page remains open and authorization is valid. The refresh button fetches immediately. Browser sleep/background throttling can delay timers.

Keep the sheet private. If using another Google account, share the sheet with that account as a Viewer or Editor; no service account is involved. For broader distribution, Google may require publishing your consent configuration and verification of the requested scope.

### Authorization lifetime

This is a client-only OAuth 2.0 implementation using Google Identity Services and the official Sheets REST API. Google remembers consent, but short-lived access tokens are kept **in memory only**, never in localStorage. After reopening the page or token expiration, click **Connect Google** again. The app cannot promise permanent one-time login without a backend to securely manage refresh tokens. It retains cached logs for viewing while disconnected. Disconnect clears the in-memory token, not Google's account-level permission; revoke that permission through your Google account if desired.

Sources: [Google token model and token expiration](https://developers.google.com/identity/oauth2/web/guides/use-token-model), [Sheets values API](https://developers.google.com/workspace/sheets/api/reference/rest/v4/spreadsheets.values/get).

## Use the dashboard

- **Filters:** weekly navigation, current month, or a custom period up to 366 days; category and specific activity filters apply to the displayed data. Hidden categories are excluded. The current streak remains anchored to today; its seven checkmarks always show this calendar week.
- **Weekly targets:** Career 12h, Fitness 6h, Relationships 8h, Mental Health 5h, Other 4h (35h total). Exact specified colors are preserved. Newly detected categories have a deterministic palette color and no target until you set one. Set target to zero to leave it unscored.
- **Goal progress:** total selected minutes divided by selected categories’ combined targets. Month/custom targets scale by days ÷ 7; a partial current week still uses the full weekly target. An activity filter narrows logged time but retains the selected categories’ budget for context. Activity targets are independent optional goals in the table and do not add to category targets.
- **Colors:** below 50% red; 50%–under 80% yellow; 80%–120% green; above 120% amber. Bars cap visually at 100%; numeric percentages do not.
- **Comparison:** selected period against the immediately preceding equal-length period. A current week is compared against the full previous week. If the previous period has zero minutes, show “No previous-period data” instead of dividing by zero.
- **Streaks:** consecutive calendar days with positive valid entries, including today. If today has no entry, current streak is zero per the specification. Duplicate daily entries count once. Personal best spans all loaded history; future dates do not extend a streak. Future valid rows can appear in date-filtered totals, so log completed activities on their actual dates.
- **Activity identity:** category + activity name, case-sensitive. An activity with the same name in two categories has separate totals. Previously seen activities remain visible at zero in unlogged periods.
- **Local log edits:** Daily Log lets you edit or hide entries in this browser. These adjustments affect calculations but **do not write to Google Sheets**, preserving the requested read-only permission. A banner shows when adjustments are active; reset restores source data. To make a permanent source edit, use “Open Google Sheet.” Local adjustments follow exact row content, including duplicate occurrence number, so they survive unrelated row insertion. If the source row changes, its old adjustment no longer applies. Row identities also include the stable Google tab ID, so equal entries in different months remain distinct and tab renaming does not transfer adjustments to another tab. Identical duplicate rows cannot be distinguished beyond occurrence order.
- **Categories:** hide any category to exclude it; remove custom category settings with the trash button. A category still in the sheet will be rediscovered. To remove it permanently, update the sheet itself.
- **Storage:** settings, goals, appearance, local edits, and the most recently fetched logs persist on this browser. Cached logs/edits are separated by spreadsheet ID and import mode, but are not a user-account security boundary. On shared devices use “Clear cached logs & adjustments” before leaving. A malformed month-tab header or incomplete API response preserves the previous combined cache instead of showing misleading partial totals. Blank tabs are skipped with a warning, and malformed individual rows report their source tab. Corrupt JSON falls back to defaults; storage failures show a warning. No backend or analytics is used. Google Fonts is optional; system sans-serif fallbacks work offline.
- **Historical view:** the eight weeks ending in the selected period, including the current partial week. All fetched rows are retained locally so maximum streak and wider filters are meaningful. A sheet too large for browser storage triggers a storage warning; the current view still works in memory.

## Troubleshooting

| Message | Fix |
|---|---|
| Missing column | Add the named header to row 1, with one occurrence of each required header. |
| Malformed rows skipped | Inspect reported row numbers; use valid dates, positive numeric minutes, and nonblank category/activity. |
| Access expired / 401 | Choose Connect Google again. Cached data is preserved. |
| Access denied / 403 | Enable Sheets API, check consent/test-user settings, and verify that the selected account can open the sheet. |
| Invalid range / 400 | A tab may have been renamed during refresh. Retry to rediscover tabs. |
| No month tabs found | Use full month names such as January or February. |
| Sheet not found / 404 | Check the spreadsheet URL and account access. |
| Popup closed / blocked | Retry sign-in and allow popups for the dashboard origin. |
| OAuth origin mismatch | Register the exact scheme, hostname, and port shown in Settings; allow time for Google's change to propagate. |
| Offline / unreachable | Cached data and its last successful timestamp remain visible. Retry when online. |
| Rate limited / 429 | Wait a few minutes, then retry. |

## Validation and project files

`npm test` verifies date parsing, DST-safe boundaries, malformed rows, totals, dynamic categories, targets, filters, zero denominators, streaks, adjustment identities, and Google API error handling. `npm run build` creates the production bundle.

- `src/App.jsx` — views, connection lifecycle, cache, settings, and local adjustments.
- `src/model.js` — pure calculations and parsing.
- `src/sheets.js` — Google Identity Services and read-only Sheets client.
- `src/style.css` — responsive light/dark design.
- `src/model.test.js` — automated calculation/error tests.

Real Google authorization must be verified with your own OAuth client and sheet. Neither was supplied with the request. No credentials or private sheet data are included in this project.
